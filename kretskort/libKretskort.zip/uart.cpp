#include "deviceStates.h"
#include "singleColorState.h"
#include "rainbowState.h"
#include "schedule.h"

unsigned long get32BitValue(const unsigned char *buf)
{
	return buf[0] | ((unsigned long)buf[1] << 8) | ((unsigned long)buf[2] << 16) | ((unsigned long)buf[3] << 24);
}

unsigned long get24BitValue(const unsigned char *buf)
{
	return (long)get32BitValue(buf) & 0xffffff;
}

//Called from readUartCommand once for every status change
//Private to module
unsigned char readStatusCommand(const unsigned char *buf)
{
	unsigned char command = buf[0];
	unsigned char commandSize = 0;
	if (command == 's') //Set state
	{
		STATE state = buf[1];
		char subState = buf[2];
		setState(state, subState);
		commandSize = 3;

	}
	else if (command == 'c') //Set color
	{
		long color = get24BitValue(buf + 1);
		setColor(color);
		commandSize = 4;
	}
	else if (command == 'b') //Set blink speed
	{
		setBlinkSpeed(buf[1]);
		commandSize = 2;
	}
	else if (command == 'f') //Set fade speed
	{
		setFadeSpeed(buf[1]);
		commandSize = 2;
	}
	
	return commandSize;
}

void readStatusCommands(const unsigned char* buf)
{
	unsigned char* statusCommandBuf = buf + 9;
	unsigned char commandSize = 0;
	while ((commandSize = readStatusCommand(statusCommandBuf)) > 0)
		statusCommandBuf += commandSize;
}


void readUartCommand()
 {
	const char BUF_SIZE = 50;
	static unsigned char commandBuf[BUF_SIZE]; //Holds incoming messages from PC
	static char readIndex;  //Where in commandBuf the next incoming character should be put

	if (Serial.available())
	{
		unsigned char c = (unsigned char)Serial.read();
		if (c == '!')  //Start of a new message
			readIndex = 0;
		else if (c == '#' || readIndex == BUF_SIZE) //End of message or message too long
		{
			//At this point the whole message is received in the buffer
			//Now we just need to parse it
			
			unsigned long scheduleId = get32BitValue(commandBuf);
			
			//Number of seconds to wait until running command
			unsigned long delay = get32BitValue(commandBuf + 4);
			
			//If recurring is true the command will run once every <delay> seconds
			bool rerun = commandBuf[8];
			
			//Read all status-changing commands or put the in schedule if delay > 0
			if (delay > 0)
				scheduleCommand(scheduleId, delay, rerun, commandBuf + 9, readIndex - 9);
			else
				readStatusCommands(commandBuf);
		}
		else
		{
			commandBuf[readIndex++] = c;
		}
	}
 }

void uartSendState(STATE state, char subState)
{
	Serial.write('!'); 
	Serial.print('s'); 
	Serial.print((char)state);
	Serial.print(subState);
	Serial.print('#'); 
}

void uartSendColor(long color)
{
	Serial.print('!'); 
	Serial.print('c');
	Serial.print((char)color);
	Serial.print((char)(color >> 8));
	Serial.print((char)(color >> 16));
	Serial.print('#'); 
}

void uartSendScheduledCommand(const ScheduledCommand *command)
{
	Serial.print('!');
	Serial.print('S');
	Serial.print((char)command->id);
	Serial.print((char)(command->id >> 8));
	Serial.print((char)(command->id >> 16));
	Serial.print((char)(command->id >> 24));
	Serial.write(command->buf, command->bufSize);
	Serial.print('#');
}
