#include "deviceStates.h"
#include "singleColorState.h"
#include "rainbowState.h"

void readUartCommand()
 {
	const char BUF_SIZE = 50;
	static char commandBuf[BUF_SIZE]; //Holds incoming messages from PC
	static char readIndex;  //Where in commandBuf the next incoming character should be put

	if (Serial.available())
	{
		char c = Serial.read();
		if (c == '!')  //Start of a new message
			readIndex = 0;
		else if (c == '#' || readIndex == BUF_SIZE) //End of message or message too long
		{
			//Parse message
			
			//First 4 bytes = how many seconds from now the command should be executed
			unsigned int time = commandBuf[0] | (commandBuf[1] << 8) | (commandBuf[2] << 16) | (commandBuf[3] << 24);
			//TODO: implement scheduling

			//Byte 5 = type of command
			char command = commandBuf[4];
			if (command == 's') //Set state
			{
				STATE state = commandBuf[5];
				char subState = commandBuf[6];
				setState(state, subState);
				Serial.println("Changed state");
				if (state == RAINBOW)
					initRainbowState();
			}
			else if (command == 'c') //Set color
			{
				long color = commandBuf[5] | (commandBuf[6] << 8) | ((long)commandBuf[7] << 16);
				setColor(color);
			}
		}
		else
		{
			commandBuf[readIndex++] = c;
		}
	}
 }

void uartSendState(STATE state, char subState)
{
	Serial.print('!'); //Signals start of message)
	Serial.print('s'); //Set state command
	Serial.print((char)state);
	Serial.print(subState);
	Serial.print('#'); //Signals end of message
}

void uartSendColor(long color)
{
	Serial.print('!'); //Signals start of message)
	Serial.print('c'); //Set color command
	Serial.print(color & 0xff);
	Serial.print((color >> 8) & 0xff);
	Serial.print((color >> 16) & 0xff);
	Serial.print('#'); //Signals end of message
}