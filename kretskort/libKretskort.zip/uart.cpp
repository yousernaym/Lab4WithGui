#include "deviceStates.h"
#include "singleColorState.h"
#include "rainbowState.h"

void readUartCommand()
 {
	const char BUF_SIZE = 50;
	static unsigned char commandBuf[BUF_SIZE]; //Holds incoming messages from PC
	static char readIndex;  //Where in commandBuf the next incoming character should be put

	if (Serial.available())
	{
		unsigned char c = (unsigned char)Serial.read();
		if (c == '!')  //Start of a new message
			readIndex = 0;
		else if (c == '#' || readIndex == BUF_SIZE) //End of message or message too long
		{
			//Parse message
			
			//First 4 bytes = how many seconds from now the command should be executed
			unsigned long time = commandBuf[0] | ((unsigned long)commandBuf[1] << 8) | ((unsigned long)commandBuf[2] << 16) | ((unsigned long)commandBuf[3] << 24);
			//TODO: implement scheduling

			//5th byte = type of command
			unsigned char command = commandBuf[4];
			if (command == 's') //Set state
			{
				STATE state = commandBuf[5];
				char subState = commandBuf[6];
				setState(state, subState);
			}
			else if (command == 'c') //Set color
			{
				long color = commandBuf[5] | ((long)commandBuf[6] << 8) | ((long)commandBuf[7] << 16);
				setColor(color);
			}
			else if (command == 'b') //Set blink speed
				setBlinkSpeed(commandBuf[5]);
			else if (command == 'f') //Set fade speed
				setFadeSpeed(commandBuf[5]);
		}
		else
		{
			commandBuf[readIndex++] = c;
		}
	}
 }

void uartSendState(STATE state, char subState)
{
	Serial.print('!'); 
	Serial.print('s'); 
	Serial.print((char)state);
	Serial.print(subState);
	Serial.print('#'); 
}

void uartSendColor(long color)
{
	Serial.print('!'); 
	Serial.print('c');
	Serial.print((char)color);
	Serial.print((char)(color >> 8));
	Serial.print((char)(color >> 16));
	Serial.print('#'); 
}