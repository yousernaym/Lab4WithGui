#ifndef __KRETSKORT__
#define __KRETSKORT__
const char FIRST_RGB_PIN = 9;
void lightsOut();
#endif
