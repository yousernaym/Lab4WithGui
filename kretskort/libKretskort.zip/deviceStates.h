#ifndef __DeviceStates__
#define __DeviceStates__

#include <arduino.h>

enum STATE { SINGLE_COLOR, RAINBOW };
enum SINGLECOLOR_SUBSTATE { CONSTANT, BLINK };
const char FIRST_RGB_PIN = 9;
const char RED_PIN = 11;
const char GREEN_PIN = 9;
const char BLUE_PIN = 10;

void lightsOut();
void initDeviceStates();
void processCurrentState();
void setState(STATE newState, char newSubState);

#endif
