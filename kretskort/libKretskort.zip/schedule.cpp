#include <arduino.h>
#include "schedule.h"

const char MAX_SCHEDULED_COMMANDS = 10;
static ScheduledCommand scheduledCommands[MAX_SCHEDULED_COMMANDS];

//From uart.cpp
void uartSendScheduledCommand(const ScheduledCommand* command);
void readStatusCommands(const unsigned char* buf);

void initSchedule()
{
	memset(scheduledCommands, 0, sizeof(scheduledCommands));
}

void scheduleCommand(unsigned long id, unsigned long delay, bool rerun, unsigned char* commandBuf, char commandBufSize)
{
	char index = -1;
	//Find empty slot for new schedule entry
	for (index = 0; index < MAX_SCHEDULED_COMMANDS; index++)
	{
		if (scheduledCommands[index].id > 0)
			break;
	}
	if (index == MAX_SCHEDULED_COMMANDS)
		return; //Schedule list full

	ScheduledCommand* command = scheduledCommands + index;
	command->id = id;
	command->delay = delay;
	command->time = millis() / 1000 + delay;
	command->rerun = rerun;
	memcpy(command->buf, commandBuf, commandBufSize);
	command->bufSize = commandBufSize;
}

void checkSchedule()
{
	unsigned long currentTime = millis() / 1000;
	for (int i = 0; i < MAX_SCHEDULED_COMMANDS; i++)
	{
		if (scheduledCommands[i].id > 0, scheduledCommands[i].time > currentTime)
		{
			uartSendScheduledCommand(&scheduledCommands[i]);
			readStatusCommands(scheduledCommands[i].buf);
			if (scheduledCommands[i].rerun)
				scheduledCommands[i].time = currentTime + scheduledCommands[i].delay;
			else
				scheduledCommands[i].id = 0; //Delete schedule entry
		}
	}

}