#include <arduino.h>
#include "schedule.h"
#include "deviceStates.h"
#include "singleColorState.h"

const char MAX_SCHEDULED_COMMANDS = 10;
static ScheduledCommand scheduledCommands[MAX_SCHEDULED_COMMANDS];

//From uart.cpp
void uartSendScheduledCommand(const ScheduledCommand* command);
void readStatusCommands(const unsigned char *buf);

void initSchedule()
{
	memset(scheduledCommands, 0, sizeof(scheduledCommands));
}

void scheduleCommand(unsigned long id, unsigned long delay, bool rerun, unsigned char* commandBuf, char commandBufSize)
{
	ScheduledCommand* command = 0;
	//Check if schedule entry with this id already exist
	for (int i = 0; i < MAX_SCHEDULED_COMMANDS; i++)
	{
		if (scheduledCommands[i].id == id)
		{
			command = scheduledCommands + i;
			break;
		}
	}
	
	if (command == 0) //Entry didn't exist, create new
	{
		//Find empty slot for new entry
		for (int i = 0; i < MAX_SCHEDULED_COMMANDS; i++)
		{
			if (scheduledCommands[i].id == 0)
			{
				command = scheduledCommands + i;
				break;
			}
		}
	}
	if (command == 0) //Schedule list full
		return; 
	
	command->id = id;
	command->delay = delay;
	command->time = millis() / 1000 + delay;
	command->rerun = rerun;
	memcpy(command->buf, commandBuf, commandBufSize);
	command->bufSize = commandBufSize;
}

void checkSchedule()
{
	unsigned long currentTime = millis() / 1000;
	int count = 0;
	for (int i = 0; i < MAX_SCHEDULED_COMMANDS; i++)
	{
		if (scheduledCommands[i].id > 0)
		{
			if (scheduledCommands[i].time < currentTime)
			{
				uartSendScheduledCommand(scheduledCommands + i);
				readStatusCommands(scheduledCommands[i].buf);
				if (scheduledCommands[i].rerun)
					scheduledCommands[i].time = currentTime + scheduledCommands[i].delay;
				else
					scheduledCommands[i].id = 0; //Delete schedule entry
			}
		}
	}
}


void removeScheduledCommand(unsigned long id)
{
	for (int i = 0; i < MAX_SCHEDULED_COMMANDS; i++)
	{
		if (scheduledCommands[i].id == id)
		{
			scheduledCommands[i].id = 0;
			break;
		}
	}
}