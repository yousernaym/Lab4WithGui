#include "deviceStates.h"
#include "singleColorState.h"
#include "rainbowState.h"
#include "uart.h"

typedef struct
{
  unsigned long lastChange;
  bool isDown;
  char pin;
} Button;

volatile Button button0, button1;

static volatile STATE state = SINGLE_COLOR;
static volatile char subState = CONSTANT; //Not declaring as enum type since the type could vary depending on main state

//Set all color components to off
void lightsOut()
{
	for (int i = FIRST_RGB_PIN; i < FIRST_RGB_PIN + 3; i++)
		digitalWrite(i, LOW);
}

//Meant to be called when a button state has changed
//Returns true if button was pressed, false if it was released
//Bouncing noise is filtered by ignoring calls less than 50 ms apart
bool buttonClick(Button *const button)
{
	unsigned long lastChange = button->lastChange;
	button->lastChange = millis();
	if (lastChange - millis() < 50)
		return false;
	return button->isDown = digitalRead(button->pin);
}

//Called by interrupt when Button0 changes state
//Switches to single-color state if it was pressed
void button0Change()
{
	if (buttonClick(&button0))
	{
		//Repeated presses will cycle through the preset colors
		if (state == SINGLE_COLOR)
			setColor(-1);
		
		//If both buttons are pressed, enable blinking
		setState(SINGLE_COLOR, button1.isDown ? BLINK : CONSTANT);
				
		//Update PC app
		uartSendState(state, subState);
		uartSendColor(getColor());
	}
}

//Called by interrupt when Button1 changes state
//Switches to rainbow state if it was pressed,
//or to single-color blink state if the other button also is pressed
void button1Change()
{
	if (buttonClick(&button1))
	{
		setState(button0.isDown ? SINGLE_COLOR : RAINBOW,
				 button0.isDown ? BLINK : CONSTANT);
		
		//Update PC app
		uartSendState(state, subState);
	}
}

void initDeviceStates()
{
  button0.pin = 2;
  button1.pin = 3;
  button0.lastChange = button1.lastChange = millis();
  pinMode(button0.pin, INPUT);
  pinMode(button1.pin, INPUT);
  pinMode(FIRST_RGB_PIN, OUTPUT);
  pinMode(FIRST_RGB_PIN + 1, OUTPUT);
  pinMode(FIRST_RGB_PIN + 2, OUTPUT);
  lightsOut();
  attachInterrupt(digitalPinToInterrupt(button0.pin), button0Change, CHANGE);
  attachInterrupt(digitalPinToInterrupt(button1.pin), button1Change, CHANGE);
}

void processCurrentState()
{
	if (state == SINGLE_COLOR)
		processSingleColorState(subState);
	else if (state == RAINBOW)
		processRainbowState();
}

void setState(STATE newState, char newSubState)
{
	state = newState;
	subState = newSubState;
	if (state == RAINBOW)
		initRainbowState();
}

