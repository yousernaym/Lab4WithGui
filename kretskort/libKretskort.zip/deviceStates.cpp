#include "deviceStates.h"
#include "singleColorState.h"
#include "rainbowState.h"

typedef struct
{
  unsigned long lastChange;
  bool isDown;
  char pin;
} Button;

volatile Button button0, button1;

static volatile STATE state = SINGLE_COLOR;
static volatile char subState = CONSTANT; //Not declaring as enum type since the type could vary depending on the main state

//Reset all color components to off
void lightsOut()
{
	for (int i = FIRST_RGB_PIN; i < FIRST_RGB_PIN + 3; i++)
		digitalWrite(i, LOW);
}

//Meant to be called when a button state has changed
//Returns true if button was pressed, false if it was released
//Bouncing noise is filtered by ignoring calls less than 50 ms apart
bool buttonClick(Button* button)
{
	unsigned long lastChange = button->lastChange;
	button->lastChange = millis();
	if (lastChange - millis() < 50)
		return false;
	return button->isDown = digitalRead(button->pin);
}

//Called by interrupt when Button0 changes state
//Switches to single-color state
void button0Change()
{
	if (buttonClick(&button0))
	{
		//If both buttons are pressed, enable blinking
		subState = button1.isDown ? BLINK : CONSTANT;
		state = SINGLE_COLOR;
		setColor(-1); //Switch to next color
	}
}

//Called by interrupt when Button1 changes state
//Switches to rainbow state
void button1Change()
{
	if (buttonClick(&button1))
	{
		//If both buttons are pressed, enable blinking
		//and activate single-color state instead of rainbow state.
		subState = button0.isDown ? BLINK : CONSTANT;
		state = button0.isDown ? SINGLE_COLOR : RAINBOW;
		initRainbowState();
	}
}

void initDeviceStates()
{
  button0.pin = 2;
  button1.pin = 3;
  button0.lastChange = button1.lastChange = millis();
  pinMode(button0.pin, INPUT);
  pinMode(button1.pin, INPUT);
  pinMode(FIRST_RGB_PIN, OUTPUT);
  pinMode(FIRST_RGB_PIN + 1, OUTPUT);
  pinMode(FIRST_RGB_PIN + 2, OUTPUT);
  lightsOut();
  attachInterrupt(digitalPinToInterrupt(button0.pin), button0Change, CHANGE);
  attachInterrupt(digitalPinToInterrupt(button1.pin), button1Change, CHANGE);
}

void processCurrentState()
{
	if (state == SINGLE_COLOR)
		processSingleColorState(subState);
	else if (state == RAINBOW)
		processRainbowState();
}

void setState(STATE newState, char newSubState)
{
	state = newState;
	subState = newSubState;
}

