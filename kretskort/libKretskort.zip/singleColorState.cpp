#include "deviceStates.h"
#include "singleColorState.h"

const char PRESET_COLOR_COUNT = 3;
const long PRESET_COLORS[] = { 0xff, 0xff00 , 0xff0000 };
static float blinkInterval = 0.5f; //0 = 100 ms, 1 = 1000 ms

//Can be changed by interrupt so should be volatile
static volatile long currentColor = PRESET_COLORS[0]; 
static volatile char currentColorIndex = 0;

void processSingleColorState(SINGLECOLOR_SUBSTATE subState)
{
	static bool blinkState = true;
	static long blinkIntervalStart = millis();

	float brightness = 0.25f; //It's too bright!
	analogWrite(RED_PIN, (currentColor & 0xff) * brightness * blinkState);
	analogWrite(GREEN_PIN, ((currentColor >> 8) & 0xff) * brightness * blinkState);
	analogWrite(BLUE_PIN, ((currentColor >> 16) & 0xff) * brightness * blinkState);

	if (subState == BLINK)
	{
		if (millis() - blinkIntervalStart > blinkInterval * 900 + 100)
		{
			blinkState = !blinkState;
			blinkIntervalStart = millis();
		}
	}
	else
		blinkState = 1;
}

//Set color to a 24-bit value or -1 to cycle to next preset color
void setColor(long color)
{
	if (color == -1)
	{
		if (++currentColorIndex == PRESET_COLOR_COUNT)
			currentColorIndex = 0;
		currentColor = PRESET_COLORS[currentColorIndex];
	}
	else
		currentColor = color;
}

long getColor()
{
	return currentColor;
}

void setBlinkSpeed(unsigned char value)
{
	blinkInterval = (255 - value) / 255.f;
}