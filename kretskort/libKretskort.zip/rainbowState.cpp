#include "deviceStates.h"

static float fadeSpeed = 0.0005f;

void initRainbowState()
{
	//Rainbow state starts with the first color component fully lit and the others off
	digitalWrite(FIRST_RGB_PIN, HIGH);
	digitalWrite(FIRST_RGB_PIN + 1, LOW);
	digitalWrite(FIRST_RGB_PIN + 2, LOW);
}

void processRainbowState()
{
	static int fadeComponent = FIRST_RGB_PIN + 1; //The color component currently being faded
	static float fade = 0;  //The amount of fade from 0 to 1
	static char sign = 1;  //1 = fade in, -1 = fade out
	analogWrite(fadeComponent, 64 * fade); //Multiply by 64 instead of 255 to not get blinded
	fade += fadeSpeed * sign;

	//If color component is fully faded in, start to fade out previous component
	if (fade > 1)
	{
		fade = 1;
		sign *= -1;
		fadeComponent--;
		if (fadeComponent < FIRST_RGB_PIN)
			fadeComponent += 3;
	}

	//If previous component is fully faded out, start to fade in next component
	else if (fade < 0)
	{
		fade = 0;
		sign *= -1;
		fadeComponent += 2;
		if (fadeComponent > FIRST_RGB_PIN + 2)
			fadeComponent -= 3;
	}
}

void setFadeSpeed(unsigned char value)
{
	fadeSpeed = value * 0.001f / 255.f;
}