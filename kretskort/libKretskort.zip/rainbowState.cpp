#include "deviceStates.h"

static float fadeSpeed = 0.0005f;

void initRainbowState()
{
	lightsOut();
	digitalWrite(FIRST_RGB_PIN, HIGH);
}

void processRainbowState()
{
	static int fadeComponent = 10; //The color component currently being faded (pin number)
	static float fade = 0;  //The amount of fade from 0 to 1
	static char sign = 1;  //1 if fading in, -1 if fading out
	analogWrite(fadeComponent, 64 * fade); //Multiply by 64 instead of 255 to not get blinded
	fade += fadeSpeed * sign;

	//If color component is fully faded in, fade out the previous component
	if (fade > 1)
	{
		fade = 1;
		sign *= -1;
		fadeComponent--;
		if (fadeComponent < FIRST_RGB_PIN)
			fadeComponent += 3;
	}

	//If color component is fully faded out, fade in next component
	else if (fade < 0)
	{
		fade = 0;
		sign *= -1;
		fadeComponent += 2;
		if (fadeComponent > FIRST_RGB_PIN + 2)
			fadeComponent -= 3;
	}
}

void setFadeSpeed(float value)
{
	fadeSpeed = value * 0.001f;
}