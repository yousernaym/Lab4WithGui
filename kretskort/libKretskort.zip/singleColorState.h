#ifndef __SingleColorState__
#define __SingleColorState__

void initSingleColorState();
void processSingleColorState(SINGLE_COLOR_STATE subState);
void setColor(long color);
long getColor();
void setBlinkInterval(float value);

#endif