#ifndef __SingleColorState__
#define __SingleColorState__

void processSingleColorState(SINGLECOLOR_SUBSTATE subState);
void setColor(long color);
long getColor();
void setBlinkSpeed(unsigned char value);

#endif