#ifndef __SingleColorState__
#define __SingleColorState__

void initSingleColorState();
void processSingleColorState(SINGLE_COLOR_STATE subState);
void setBlinkInterval(float value);
void setBrightness(float value);
void setColor(long color);

#endif