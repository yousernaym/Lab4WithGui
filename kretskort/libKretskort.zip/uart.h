#ifndef __UART__
#define __UART__

void readUartCommand();
void readStatusCommands(const unsigned char *buf);
void uartSendState(STATE state, char substate);
void uartSendColor(long color);

#endif
