#ifndef __UART__
#define __UART__

void readUartCommand();
void uartSendState(STATE state, char substate);
void uartSendColor(long color);

#endif
