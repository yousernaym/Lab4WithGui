#ifndef __UART__
#define __UART__

void readUartCommand();

#endif
