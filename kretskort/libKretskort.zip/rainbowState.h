#ifndef __RainbowState__
#define __RainbowState__

void initRainbowState();
void processRainbowState();
void setFadeSpeed(float value);

#endif