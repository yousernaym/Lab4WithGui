#ifndef __RainbowState__
#define __RainbowState__

void initRainbowState();
void processRainbowState();
void setFadeSpeed(unsigned char value);

#endif