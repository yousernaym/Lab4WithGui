void processRemoteState();
