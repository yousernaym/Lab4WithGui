typedef struct
{
	unsigned long id;
	unsigned long time;
	unsigned long delay;
	bool rerun;
	unsigned char buf[40];
	char bufSize;
} ScheduledCommand;

void initSchedule();
void scheduleCommand(unsigned long id, unsigned long delay, bool rerun, unsigned char* commandBuf, char commandBufSize);
void checkSchedule();
void removeScheduledCommand(unsigned long id);
