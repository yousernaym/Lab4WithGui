#ifndef __Schedule__
#define __Schedule__

typedef struct
{
	unsigned long id;
	unsigned long time;
	unsigned long delay;
	bool rerun;
	unsigned char buf[50];
	char bufSize;
} ScheduledCommand;

void initSchedule();
void scheduleCommand(unsigned long id, unsigned long delay, bool rerun, unsigned char* commandBuf, char commandBufSize);
void checkSchedule();
void removeScheduledCommand(unsigned long id);

#endif