#ifndef __LOCAL_STATES__
#define __LOCAL_STATES__
const byte BUTTON0_PIN = 2;
const byte BUTTON1_PIN = 3;
void initButtons();
bool button0Click(char *out_state);
bool button1Click(char* out_state);
void processLocalState(char state);
#endif
